<?php
ini_set("display_errors","On");
error_reporting(E_ALL);
use QCloud_WeApp_SDK\Mysql\Mysql as DB;
class RecordUser_model extends CI_Model
{
  public static $tempnow;
    public function __construct()
    {
        $this->load->database();//加载数据库类
    }

    //添加参与用户
    public function add($userID,$activityID=NULL)
    {
       
    
      if($activityID==NULL)
      {
      $query = $this->db->get_where('User', array('Qualification' => 6));
      $data=$query->row_array();
      $temp=$data['ActivityID'];
      $res=DB::insert('User', [
            'UserID'=>$userID,
            'ActivityID' =>$temp,
            'Qualification' => 0,
   ]);
   $res11 = DB::delete('User', ['Qualification' => 6]);
      }
      else
      {
        self::$tempnow=$activityID;
        $res=DB::insert('User', [
            'UserID'=>0,
            'ActivityID' => $activityID,
            'Qualification' => 6,
   ]);
      }
        

    }

    public function insertqual($userID,$activityID)
    {

      if($activityID==NULL)
      {
      $query = $this->db->get_where('User', array('Qualification' => 6));
      $data=$query->row_array();
      $temp=$data['ActivityID'];
      $res=DB::insert('User', [
            'UserID'=>$userID,
            'ActivityID' =>$temp,
            'Qualification' => 1,
   ]);
   $res11 = DB::delete('User', ['Qualification' => 6]);
   $query11 = $this->db->get_where('User', array('ActivityID' => $temp,'UserID' => $userID,'Qualification'=>0));
   if(!is_null($query11))
   {
     $this->db->delete('User',array('ActivityID' => $temp,'UserID' => $userID,'Qualification'=>0));
   }
      }
      else
      {
        self::$tempnow=$activityID;
        $res=DB::insert('User', [
            'UserID'=>0,
            'ActivityID' => $activityID,
            'Qualification' => 6,
   ]);
      }
    }
    //添加特等奖资格用户
    public function addQualification($userID,$activityID=NULL)
    {
        $query = $this->db->get_where('User', array('ActivityID' => $activityID,'UserID' => $userID));
        if(is_null($query))
        {
            $qualif = 1;
            $data = array(
                'UserID' => $userID ,
                'ActivityID' => $activityID ,
                'Qualification' => $qualif
            );

            $this->db->insert('user1', $data);

            echo "successful";
        }
        else{
            $this->db->delete('Recipient',array('ActivityID' => $activityID,'UserID' => $userID));
            $qualif = 1;
            $data = array(
                'UserID' => $userID ,
                'ActivityID' => $activityID ,
                'Qualification' => $qualif
            );

            $this->db->insert('user1', $data);

            echo "successful";
        }

    }
}