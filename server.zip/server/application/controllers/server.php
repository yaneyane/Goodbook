<?php //server.php
public function create()
{
$this->load->helper('url');
value1 =>$this->input->get('id')
}


?>